# BLOX — Proyek Android

Nama aplikasi: **BLOX**  
ID aplikasi: `com.sanzz.blox`  
Teknologi pembungkus Android: **Capacitor 7**  
Sumber aplikasi web: `www/index.html`

## Isi paket
- `www/index.html` — HTML BLOX yang kamu unggah, dipakai sebagai tampilan aplikasi.
- `www/manifest.webmanifest` — metadata web app.
- `assets/icon.png` — ikon utama aplikasi 1024×1024.
- `package.json` dan `capacitor.config.json` — konfigurasi proyek Capacitor.

## Cara build APK (Windows / macOS / Linux)
Persyaratan: Node.js 20 atau lebih baru, Android Studio, Android SDK, dan koneksi internet saat memasang dependensi.

1. Ekstrak ZIP ini.
2. Buka terminal di folder `BLOX_ANDROID_PROJECT`.
3. Jalankan:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

4. Android Studio akan terbuka. Tunggu Gradle Sync selesai.
5. Untuk APK uji coba: pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Untuk APK rilis: pilih **Build > Generate Signed Bundle / APK** dan buat keystore milikmu sendiri. Simpan keystore dan password dengan aman.

Jika folder `android` sudah pernah dibuat, jangan jalankan `npx cap add android` lagi. Cukup jalankan `npx cap sync android`.

## Ikon aplikasi
File ikon 1024×1024 ada di `assets/icon.png`. Di Android Studio, buka proyek Android setelah dibuat, lalu gunakan **New > Image Asset** pada folder `android/app/src/main/res` untuk memasang ikon launcher dari file tersebut.

## Catatan pemeriksaan
- File JavaScript HTML diperiksa dengan `node --check` dan tidak ditemukan kesalahan sintaks JavaScript.
- Pemeriksaan sintaks bukan jaminan bahwa semua fitur berjalan sempurna di Android atau bahwa proses Gradle build pasti sukses. Build akhir harus diuji di Android Studio dengan Android SDK yang sesuai.
- Fitur daftar akun/login dan saldo dalam HTML sumber saat ini menggunakan penyimpanan browser/demo lokal. Ini **belum** menjadi autentikasi online atau multiplayer sungguhan.
- Tombol Google/Apple pada HTML sumber memberi informasi demo, bukan login OAuth aktif.
- Game yang terlihat pada HTML sumber belum merupakan game 3D online penuh. Paket ini membungkus HTML yang ada menjadi kerangka proyek Android; tidak mengubahnya menjadi server multiplayer.
- Sebagian gambar latar menggunakan URL internet, sehingga gambar tersebut memerlukan koneksi internet.

## Jika build gagal
Salin pesan error Gradle lengkap dari Android Studio, terutama bagian `What went wrong`, lalu kirimkan agar dapat diperiksa. Jangan menghapus file konfigurasi secara acak.
